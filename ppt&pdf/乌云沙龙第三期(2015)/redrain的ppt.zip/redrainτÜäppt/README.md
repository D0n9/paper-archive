Using CLI slide
